# StormWatch One

Live radar, weather alerts, and forecast app. Built with HTML, CSS, and JS. Ready for deployment to Railway, Vercel, or Render.